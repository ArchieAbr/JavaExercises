/**
 * Represents a point in space and time, recorded by a GPS sensor.
 *
 * @author YOUR NAME
 */
public class Track {
  // TODO: Create a stub for the constructor

  // TODO: Create a stub for readFile()

  // TODO: Create a stub for add()

  // TODO: Create a stub for get()

  // TODO: Create a stub for size()

  // TODO: Create a stub for lowestPoint()

  // TODO: Create a stub for highestPoint()

  // TODO: Create a stub for totalDistance()

  // TODO: Create a stub for averageSpeed()
}
