import javafx.application.Application;


/**
 * JavaFX application to plot elevations of a GPS track, for
 * the Advanced task of COMP1721 Coursework 1.
 *
 * @author YOUR NAME HERE
 */
public class PlotApplication extends Application {
  // OPTIONAL: Implement the elevation plotting application here
}
